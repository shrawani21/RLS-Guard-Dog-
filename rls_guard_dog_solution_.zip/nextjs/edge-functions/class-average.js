/**
 * Example Edge Function (Node-like) that:
 * - Connects to Supabase using SERVICE_ROLE (server)
 * - Queries progress table to compute average per classroom
 * - Writes results to MongoDB collection `class_averages`
 *
 * NOTE: Deploy this as a secure server-side function and never expose SUPABASE_SERVICE_ROLE_KEY to clients.
 */

import fetch from 'node-fetch';
import { MongoClient } from 'mongodb';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const MONGODB_URI = process.env.MONGODB_URI;
const MONGODB_DB = process.env.MONGODB_DB || 'rls_guard';

export default async function handler(req, res) {
  try {
    // 1) Query Supabase (use Postgres REST or GraphQL or use the Postgres client)
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/progress?select=classroom_id,avg(score)&group=classroom_id`, {
      headers: {
        apikey: SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
      }
    });
    const averages = await resp.json();

    // 2) Write to MongoDB
    const client = new MongoClient(MONGODB_URI);
    await client.connect();
    const db = client.db(MONGODB_DB);
    const collection = db.collection('class_averages');

    const docs = averages.map(a => ({
      classroom_id: a.classroom_id,
      average_score: parseFloat(a.avg),
      recorded_at: new Date()
    }));

    if (docs.length) {
      await collection.insertMany(docs);
    }

    await client.close();

    return res.status(200).json({ ok: true, inserted: docs.length, docs });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}
