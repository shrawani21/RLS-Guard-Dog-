import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function Home() {
  const [session, setSession] = useState(null);

  useEffect(() => {
    setSession(supabase.auth.getSession?.());
  }, []);

  return (
    <div style={{padding:20}}>
      <h1>RLS Guard Dog - Demo</h1>
      <p>This is a scaffold. Log in with Supabase to continue.</p>
      <a href="/teacher">/teacher (protected)</a>
    </div>
  );
}
