import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function TeacherPage() {
  const [user, setUser] = useState(null);
  const [progress, setProgress] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function load() {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        // redirect to sign-in
        window.location.href = '/';
        return;
      }
      setUser(session.user);
      // fetch progress rows visible to this user
      const { data, error } = await supabase.from('progress').select('*').order('updated_at', { ascending: false }).limit(100);
      if (error) {
        console.error('fetch error', error);
      } else {
        if (mounted) setProgress(data);
      }
      setLoading(false);
    }
    load();
    return () => { mounted = false; }
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <div style={{padding:20}}>
      <h1>Teacher Dashboard</h1>
      <p>User: {user?.email}</p>
      <h2>Progress rows (visible by RLS)</h2>
      <table border="1" cellPadding="6">
        <thead><tr><th>student_id</th><th>subject</th><th>score</th><th>updated_at</th></tr></thead>
        <tbody>
          {progress.map(p => (
            <tr key={p.id}>
              <td>{p.student_id}</td>
              <td>{p.subject}</td>
              <td>{p.score}</td>
              <td>{p.updated_at}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
