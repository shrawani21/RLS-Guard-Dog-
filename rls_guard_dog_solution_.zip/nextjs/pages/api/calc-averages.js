import fetch from 'node-fetch';

export default async function handler(req, res) {
  // This API is an example that triggers the edge function which calculates class averages.
  // Replace EDGE_FUNCTION_URL with your deployed edge function endpoint.
  const EDGE_FUNCTION_URL = process.env.EDGE_FUNCTION_URL;
  if (!EDGE_FUNCTION_URL) return res.status(500).json({ error: 'EDGE_FUNCTION_URL not configured' });

  const r = await fetch(EDGE_FUNCTION_URL, { method: 'POST' });
  const data = await r.json();
  return res.status(200).json({ ok: true, data });
}
