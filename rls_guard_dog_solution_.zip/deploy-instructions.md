Deployment Instructions (summary)
================================

1) Supabase
- Create a Supabase project.
- In SQL editor, run `sql/policies.sql`.
- Add users manually or connect Supabase Auth providers.
- Ensure profiles in `users` table map to auth.users ids, and set `role`, `school_id`, etc.

2) MongoDB
- Create a MongoDB Atlas cluster and get connection string.
- Create database `rls_guard` and collection `class_averages` (optional, will be created on insert).

3) Next.js app
- Copy `nextjs/` to your project.
- Add environment variables (see `.env.example`).
- Deploy to Vercel (recommended) or any Node.js hosting.
- Make sure `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` are set.
- For server operations (edge function), set `SUPABASE_SERVICE_ROLE_KEY` and `MONGODB_URI` as protected env vars.

4) Edge Function
- Deploy the `edge-functions/class-average.js` to Supabase Edge Functions or Vercel Edge Functions.
- Set environment variables on deploy: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, MONGODB_URI, MONGODB_DB.

5) Testing
- Create sample data in Supabase: schools -> classrooms -> users -> progress.
- Sign in as teacher (role=teacher) and visit `/teacher` to see RLS enforced rows.
- Call `/api/calc-averages` endpoint or schedule the edge function to run periodically.

Security notes:
- Keep service role keys on server side only.
- Use rate limits for edge function invocations if scheduled externally.
