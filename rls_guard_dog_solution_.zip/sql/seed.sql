-- Seed data for demo (replace UUIDs with actual auth.user ids)
-- Create one school, one teacher, two students, one classroom and progress rows

-- Note: Replace the user UUIDs below with the UUIDs from `auth.users` in your Supabase project,
-- and populate the `users` profile table accordingly so RLS works with auth.uid().

-- Example UUIDs (placeholders)
-- teacher_id: '11111111-1111-1111-1111-111111111111'
-- student_a:  '22222222-2222-2222-2222-222222222222'
-- student_b:  '33333333-3333-3333-3333-333333333333'

INSERT INTO schools (id, name) VALUES ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Demo High School');

INSERT INTO users (id, full_name, role, school_id, classroom_id) VALUES
('11111111-1111-1111-1111-111111111111', 'Ms. Ada Teacher', 'teacher', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', NULL),
('22222222-2222-2222-2222-222222222222', 'Ravi Student', 'student', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', NULL),
('33333333-3333-3333-3333-333333333333', 'Priya Student', 'student', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', NULL),
('44444444-4444-4444-4444-444444444444', 'Headmaster', 'head_teacher', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', NULL);

INSERT INTO classrooms (id, name, school_id, teacher_id) VALUES
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '10-A', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111');

-- Update students to assign classroom_id
UPDATE users SET classroom_id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb' WHERE id IN ('22222222-2222-2222-2222-222222222222', '33333333-3333-3333-3333-333333333333');

-- Progress
INSERT INTO progress (student_id, classroom_id, school_id, subject, score) VALUES
('22222222-2222-2222-2222-222222222222', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Math', 78),
('22222222-2222-2222-2222-222222222222', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Science', 85),
('33333333-3333-3333-3333-333333333333', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Math', 92),
('33333333-3333-3333-3333-333333333333', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Science', 88);
