-- Supabase SQL: tables and RLS policies for RLS Guard Dog

-- 1) Users table (profiles) - linked to auth.users via id
create table if not exists users (
  id uuid primary key references auth.users on delete cascade,
  full_name text,
  role text not null default 'student', -- 'student' | 'teacher' | 'head_teacher' | 'admin'
  school_id uuid,
  classroom_id uuid -- optional: the classroom a student belongs to or teacher's primary class
);

-- 2) Schools table
create table if not exists schools (
  id uuid primary key default gen_random_uuid(),
  name text not null
);

-- 3) Classrooms table
create table if not exists classrooms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  school_id uuid references schools(id),
  teacher_id uuid references users(id)
);

-- 4) Progress table
create table if not exists progress (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references users(id),
  classroom_id uuid references classrooms(id),
  school_id uuid references schools(id),
  subject text,
  score numeric,
  updated_at timestamptz default now()
);

-- Enable RLS on progress
alter table progress enable row level security;

-- Policy: students can access only their own progress rows (select, update if student)
create policy "students_own_progress" on progress
  for all
  using ( auth.uid() = student_id )
  with check ( auth.uid() = student_id );

-- Policy: teachers can access rows for classrooms they teach (select, update)
create policy "teachers_class_progress" on progress
  for all
  using (
    exists (
      select 1 from classrooms c where c.id = progress.classroom_id and c.teacher_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from classrooms c where c.id = progress.classroom_id and c.teacher_id = auth.uid()
    )
  );

-- Policy: head_teacher can access all rows for their school
create policy "head_teacher_school_access" on progress
  for all
  using (
    exists (
      select 1 from users u where u.id = auth.uid() and u.role = 'head_teacher' and u.school_id = progress.school_id
    )
  )
  with check (
    exists (
      select 1 from users u where u.id = auth.uid() and u.role = 'head_teacher' and u.school_id = progress.school_id
    )
  );

-- Allow service_role (server) to bypass RLS if using service key for backend operations (do NOT expose client-side)
-- Note: Supabase automatically allows service_role to bypass RLS.
