# RLS Guard Dog - Mini Project (Solution)
This repository contains a complete solution scaffold for the **RLS Guard Dog** assignment.

## What's included
- `nextjs/` — Next.js app scaffold with Supabase Auth integration and protected `/teacher` page.
- `sql/policies.sql` — SQL to create tables and row-level security policies.
- `edge-functions/class-average.js` — Example Edge Function that calculates class averages and writes to MongoDB.
- `docs/solution.doc` — Detailed solution description (plain text doc).
- `.env.example` — Example environment variables required.
- `deploy-instructions.md` — Step-by-step deployment instructions.

## How to use
1. Read `deploy-instructions.md`.
2. Populate environment variables.
3. Deploy the Next.js app to Vercel or similar and deploy edge function to Supabase Edge Functions (or platform of choice).


## Additional files added
- `docs/solution.docx` - Word version of the solution document.
- `sql/seed.sql` - SQL seed file with example data to populate a demo workspace.
